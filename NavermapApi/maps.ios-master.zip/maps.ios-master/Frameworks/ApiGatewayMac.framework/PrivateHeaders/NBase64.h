//
//  NBase64.h
//  ApiGateway-MAC
//
//  Created by KJ KIM on 10. 03. 24.
//  Copyright 2010 NHN. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NBase64 : NSObject {

}

+ (NSString*) encode:(NSData*)data;
@end
