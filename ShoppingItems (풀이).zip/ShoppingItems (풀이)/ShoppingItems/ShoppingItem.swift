//
//  ShoppingItems.swift
//  ShoppingItems
//
//  Created by giftbot on 2018. 6. 20..
//  Copyright © 2018년 giftbot. All rights reserved.
//

import Foundation

struct ShoppingItem {
  let title: String
  let imageName: String
  let stockHoldings: Int
}
